#include <bits/stdc++.h>
using namespace std;

int main() {
    double numbers[5];  
    
    for (int i = 0; i < 5; i++) {
        cin >> numbers[i];
    }

    double max = numbers[0];
    double min= numbers[0];

    for (int i = 1; i < 5; i++) {
       
        if (numbers[i] > max) {
            max = numbers[i]; 
        }
        
        if (numbers[i] < min) {
            min = numbers[i]; 
        }
    }

    double sum = max + min;

    cout << sum << endl;

    return 0;
}