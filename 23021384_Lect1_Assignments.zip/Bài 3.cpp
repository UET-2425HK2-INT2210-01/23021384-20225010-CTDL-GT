#include <bits/stdc++.h>

using namespace std;

int UCLN(int m, int n) {
    while (n != 0) {
        int tamthoi = n;
        n = m % n;
        m = tamthoi;
    }
    return m;
}
int main()
{
    int m, n;
    
    cin >> m >> n;
    
    cout << UCLN(m, n) << endl;
    return 0;
}
